# ASR Labeling Platform

## Setup
1. Create data directory:
   ```bash
   mkdir -p data/audio_files